# Change Log

## [1.0.1] 2021-01-13
### Bug fixing, Improvements

- Bump UI: [Jinja Material](https://github.com/app-generator/jinja-material-dashboard) v1.0.2
- Bump Codebase: [Django Dashboard](https://github.com/app-generator/boilerplate-code-django-dashboard) v1.0.4 

## [1.0.0] 2020-02-07
### Initial Release
